# Tap Plumbing Corp website redesign concept

This project is a static, multi-page redesign concept for Tap Plumbing Corp. Python's standard library generates pre-rendered HTML from shared templates and source-backed content data.

## Build and preview

From the project root, run `python3 -m src.build_site` to regenerate `dist/`. Serve the output directory on port 3000 with `python3 -m http.server 3000 --bind 0.0.0.0 --directory dist`.

The estimate workflow is a prototype. It validates the request in the browser and can prepare a `mailto:` draft addressed to the company's published email. It does not deliver form submissions to the company. Optional files remain on the visitor's device and must be attached manually after the email draft opens. A backend or email integration is required for direct online submission.

The project portfolio uses clearly labeled placeholders because project-photo provenance could not be verified. Project captions and testimonial quotations/attributions are transcribed from the current official site; the business should confirm them and supply approved photo assets before production use.

## Public sources and verification

- Official company site and primary source for business facts: [tapplumbingcorp.com](https://tapplumbingcorp.com/).
- Official service pages consulted: [commercial plumbing](https://tapplumbingcorp.com/services/commercial-plumbing), [residential plumbing](https://tapplumbingcorp.com/services/residential-plumbing), [new construction](https://tapplumbingcorp.com/services/new-construction), and [kitchen and bathroom renovations](https://tapplumbingcorp.com/services/bathroom-kitchen-renovations).
- Official [projects page](https://tapplumbingcorp.com/projects) and [contact page](https://tapplumbingcorp.com/contact) were used to verify published project categories and contact details.
- Third-party recognition source: [BuildZoom Tap Plumbing Corp profile](https://www.buildzoom.com/contractor/tap-plumbing-corp). Any score or percentile is dynamic third-party information, not a company certification or a permanent rating; verify it again before a production launch.

The prototype uses the company's published phone, email, address, office hours, license numbers, service areas, service categories, project captions, and testimonial wording. Before production, have the company confirm the contact details and license information, approve testimonial quotations and attributions, verify each project location and scope, and provide photographs with confirmed usage rights. The project is available in WebDev Preview and has not been published to the company's production domain.
