# Tap Plumbing Corp — Implementation Plan

## Product and implementation approach

Build a complete multi-page redesign for Tap Plumbing Corp as a static, server-rendered website. The project starts empty and does not need account login, a database, customer-email delivery credentials, or a backend for this concept. Use a small Python standard-library site generator to render shared templates and content data into meaningful HTML pages. Serve the generated site on the WebDev preview port with Python's standard-library HTTP server. Use browser JavaScript only for accessible menu behavior, estimate-form branching/validation, and small progressive enhancements. Do not add third-party runtime dependencies.

The estimate form is a transparent prototype because no delivery backend is configured. It collects the visitor's information in the browser, validates it, and opens a pre-addressed email draft to Office@tapplumbingcorp.com. The confirmation explains that nothing was submitted to the website and that the visitor must send the draft themselves. Optional files remain local in the browser; list selected filenames in the email body and instruct visitors to attach those files manually. Keep click-to-call and direct email links available as alternatives.

Generate page content into static HTML so route-specific content and metadata exist before JavaScript runs. Provide unique title/description/Open Graph metadata, semantic HTML, descriptive image alternatives, JSON-LD using verified facts, a route manifest, sitemap and robots documents. Use the actual official domain only as the intended production origin, not an internal Preview address. Do not claim a production deployment or wire production-domain publication.

## Scope

- Homepage with navigation, project-estimate hero, verified credentials, two audience pathways, commercial capabilities, project showcase, service grid, three-step process, current-site testimonials, unique FAQ, final CTA and contact-rich footer.
- Service overview and dedicated pages for commercial plumbing, residential plumbing, new construction, kitchen and bathroom renovations, gas piping, fixture installation, plumbing repairs, and water heaters/boilers.
- Commercial capabilities, project portfolio, About, Contact, Areas Served overview, and distinct location pages for Bronx, Manhattan, Queens, Brooklyn, and Westchester County. Location copy uses only published service areas and the current site's own listed examples; do not imply that service availability is guaranteed for a specific address. The company should verify project details and imagery before production use.
- Estimate workflow with customer/project type, conditional follow-up questions, contact details, accessible validation and a clear prototype handoff to email.
- Mobile-first navigation and a persistent, non-obstructive mobile call/estimate CTA.

## Verified business information and content boundaries

The official website currently lists phone 718-337-8749, email Office@tapplumbingcorp.com, address 3004 Middletown Rd Unit 3, Bronx, NY 10461, weekday hours Monday–Friday 9:00 a.m.–5:00 p.m. and weekends closed, NYC Master Plumber License #2164, Westchester County License #1733, and licensed/insured status. It lists service across the Bronx, Manhattan, Queens, Brooklyn and Westchester County and all eight service categories. The official homepage currently contains three testimonials and project-type/location/scope captions; preserve quotes/attributions exactly if used and mark them for owner approval. The BuildZoom profile currently reports score 112 and top 3% of New York licensed contractors; describe it only as third-party, time-sensitive recognition and link to the source. Do not repeat the current homepage's one-business-day response promise or assert project outcomes, 24/7 service, guarantees, capacities, awards, or unverified response times.

The current official homepage contains plumbing and project images, but their provenance as Tap Plumbing Corp staff/completed projects could not be independently verified. Do not present those images as proof of completed company projects. Use deliberately designed, replaceable project-photo placeholders with a clear owner-verification label. Include visible owner-verification notes for project photos/details and testimonial approval in the concept handoff. No fake reviews, ratings, credentials, outcomes or service guarantees.

## Design system

### Design Movement
Modern architectural editorial for a licensed building-trades contractor: structured like an engineering field guide rather than a generic home-services landing page.

### Core Principles
1. Commercial credibility is visible immediately, without making residential visitors feel secondary.
2. Technical capability is expressed through disciplined typography, diagrams and factual labels—not decorative gradients or unsupported claims.
3. Every major section has a clear next step and an accessible reading path.
4. Project proof is handled honestly: owner-verified facts and images only, with placeholders called out plainly.

### Color Philosophy
Use deep ink navy to communicate stability and technical competence; warm white and pale stone to keep long pages readable; a restrained, ownable Tap blue for links, focus states and primary conversion actions. Use neutral greys for secondary information, with no excessive gradients or unnecessary ornamental color.

### Layout Paradigm
An editorial, asymmetrical split hero leads into broad, left-aligned section bands. The commercial story gets a substantial full-width section before the service directory. On large screens, project cards alternate between wide image placeholders and narrow text panels; on mobile, cards and controls become a simple single column. Avoid a repetitive centered grid-only structure.

### Signature Elements
- A fine-line pipe/riser route motif with small junction dots, used in section dividers and the process steps.
- Compact license and service-area chips styled like technical schedule labels.
- Oversized section numerals and thin blue rules that make long pages easy to scan.

### Interaction Philosophy and Animation
Interactions should clarify, not surprise: direct links, visible focus, predictable menu behavior and no hover-only content. Use short opacity/position transitions for navigation and disclosure only. Respect `prefers-reduced-motion`; do not animate large images, background gradients or essential content.

### Typography System
Use Manrope for display headings and Source Sans 3 for paragraph/UI text, with system sans-serif fallbacks and `font-display: swap`. Headings use compact line lengths and clear weight contrast; body text remains generous and readable. Form controls use the body family and comfortable touch sizing.

### Brand Essence and Voice
Positioning: licensed plumbing for NYC and Westchester buildings, businesses and homes, with commercial capabilities and clear residential pathways. Personality: capable, straightforward, dependable. Headlines and calls to action are direct and specific. Example lines: “Plumbing scope, clearly discussed.” “Tell us what the building needs.”

### Wordmark & Logo
Create an original typographic lockup for TAP PLUMBING CORP with a simple pipe-elbow/T-riser monogram. Keep it clearly a redesign concept, not a claim that the company supplied an official vector logo.

### Signature Brand Color
Tap Blue: a restrained mid-blue for interactive and informational emphasis, paired with deep navy rather than used as a large background wash.

## Project structure

- `src/site_data.py`: verified business facts, navigation, services, areas, public project captions, testimonials, FAQs and per-route content.
- `src/site_templates.py`: shared document shell, header, footer, CTAs, cards, structured metadata, service and location page renderers.
- `src/build_site.py`: generates static output and route-specific metadata from the content/template modules.
- `src/assets/`: authored logo mark and local styles/scripts.
- `src/assets/site.css`: responsive design system, layout, accessibility and reduced-motion rules.
- `src/assets/site.js`: mobile navigation, accessible FAQ behavior and estimate-form conditional steps/validation/mailto draft creation.
- `dist/`: generated static pages, route manifest, sitemap and robots file served in Preview.
- `plan.md`, `TODO.md`: approved product/design plan and explicit deliverable criteria.

## Build and delivery workflow

Use project-managed WebDev Preview on the configured port. Register Python, HTML, CSS and JavaScript diagnostics before application code. Run the Python generator, start the static HTTP server on `0.0.0.0` at the configured port, and verify that the homepage and representative routes return complete HTML. Exercise navigation, click-to-call, estimate branching/validation/mailto draft content and mobile layout in Preview. Keep the site as a redesign concept; production domain mapping, real lead delivery, and final project-photo/testimonial approval remain unconfigured and require business-owner action.
