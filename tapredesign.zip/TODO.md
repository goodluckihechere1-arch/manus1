# Delivery outcomes

## 1. Responsive information architecture, navigation, and technical SEO — COMPLETE
- Build the complete website, not just a static homepage screenshot.
- Ensure the layout works across mobile phones, tablets, laptops, and large desktop screens.
- Use reusable components, maintainable code, optimized assets, and a consistent design system.
- Include Services, Commercial Plumbing, Projects, About, Contact, a prominent “Request an Estimate” button, and a clearly visible clickable phone number in the header.
- On mobile, keep navigation simple and provide a persistent, unobtrusive call-to-action area for calling or requesting an estimate.
- Make all buttons and links functional. Do not include decorative controls that appear interactive but do nothing.
- Create unique page titles and meta descriptions, a logical heading hierarchy, descriptive image alt text, canonical URLs where appropriate, XML sitemap and robots.txt where supported, appropriate local business/plumbing structured data using verified facts only, fast-loading responsive images, semantic HTML, good accessibility and color contrast, optimized mobile performance, and internal links between relevant services, projects, and location information.
- Create dedicated service pages for important service categories and improve internal navigation between them.
- Where justified by real service coverage, provide genuinely useful, distinct location-specific pages for the Bronx, Manhattan, Queens, Brooklyn, and Westchester County. Do not create thin duplicated pages or promise Google rankings.
- Do not invent SEO metrics, keyword rankings, traffic numbers, or conversion improvements.

## 2. Homepage hero, trust, and customer pathways — COMPLETE
- Hero headline may be “Professional Plumbing Solutions for Buildings, Businesses & Homes.” Supporting copy: “From commercial plumbing and new construction to residential repairs and renovations, Tap Plumbing Corp delivers plumbing solutions across New York City and Westchester County.”
- Provide primary CTA “Request a Project Estimate” and secondary CTA “Call 718-337-8749”. Show genuine available project imagery where possible. Do not imply 24/7 emergency service because the existing website lists weekday office hours.
- Create a compact trust section highlighting only verifiable information: NYC Master Plumber License #2164; Westchester County License #1733; licensed and insured status as stated by the company; existing BuildZoom recognition accurately described and linked to its source if possible. Do not create fake certifications or ratings.
- Create two prominent pathways. “Commercial & Construction Plumbing” speaks to contractors, property managers, developers, and commercial building owners; highlights project coordination, new construction, multi-family plumbing, commercial renovations, and existing-site-supported services; CTA “Discuss a Commercial Project”. “Residential Plumbing” speaks to homeowners needing repairs, fixtures, kitchen and bathroom plumbing, gas piping, water heaters, and boilers; CTA “Request Residential Service”. Each CTA leads to its appropriate service section or estimate workflow.
- Preserve accurate company details and do not invent credentials, reviews, project outcomes, guarantees, awards, or service availability.

## 3. Commercial capabilities and service directory — COMPLETE
- Give commercial plumbing a dedicated section explaining types of projects the company undertakes, relevant installation and renovation services, coordination with contractors and property managers, permits and inspections where applicable, and how a prospective client can begin discussing a project.
- Keep every statement grounded in the existing website. Do not promise response times, project capacities, warranties, or outcomes that have not been verified.
- Present all major services in a clean, scannable grid. Every card has a concise description and a working link to its corresponding service page.
- Preserve all existing major service categories: commercial plumbing; residential plumbing; new construction plumbing; kitchen and bathroom renovations; gas piping; fixture installation; plumbing repairs; water heaters and boilers.

## 4. Project portfolio and proof — COMPLETE
- Create a polished project showcase using the existing website's project categories: multi-family plumbing installation; pipe installation and replacement; bathroom renovation plumbing; kitchen plumbing renovation; fixture installation; residential plumbing repair.
- Use genuine available images if they can be sourced and verified. If genuine project photos are unavailable, use clearly replaceable image placeholders and label the content for later verification.
- Design each project card to support project type, location, scope of work, relevant imagery, and a link to a detailed case study where actual project details are available.
- Never fabricate project photographs or claim that illustrative images depict completed Tap Plumbing Corp projects.
- Use only authentic, approved testimonials from the existing website or verified sources. Preserve accuracy of quotations and attributions. Do not invent customers, review counts, star ratings, or endorsements.

## 5. Process, FAQ, final CTA, and footer — COMPLETE
- Explain the process in three steps: (1) Tell us about your plumbing needs or project. (2) Discuss the scope and request an estimate. (3) Coordinate the next steps with the Tap Plumbing Corp team.
- Do not guarantee that every estimate will be delivered within a particular timeframe unless verified.
- Replace duplicated FAQ questions on the existing homepage with unique useful questions: What areas does Tap Plumbing Corp serve? Do you handle commercial and residential plumbing? Can you work on new construction projects? Can property managers request commercial plumbing estimates? Do you coordinate permits and inspections? How can I request a plumbing estimate? What information should I provide about my project? Answers must be based on verified company information. If a detail is unknown, phrase the answer so the visitor can contact the company rather than inventing a policy.
- Final CTA headline: “Planning a Plumbing Project?” Supporting text invites homeowners, contractors, and property managers to explain their requirements. Buttons: “Request an Estimate” and “Call 718-337-8749”.
- Footer includes verified company name, phone number, email, address, weekday office hours, service areas, important service links, and privacy information where appropriate.
- Verify details against the current website before finalizing. Current official details: 718-337-8749; Office@tapplumbingcorp.com; 3004 Middletown Rd Unit 3, Bronx, NY 10461; Monday–Friday 9:00 a.m.–5:00 p.m.; Saturday/Sunday closed.

## 6. Accessible estimate-request prototype and contact pathways — COMPLETE
- Build an intuitive, mobile-friendly estimate workflow that begins by asking the visitor what kind of project they have.
- Step 1 selections: Commercial property; New construction; Multi-family building; Residential repair; Kitchen or bathroom renovation; Other plumbing project.
- Step 2 relevant follow-up questions: which plumbing service is required; where the property is located; urgent repair or planned project; approximate project scope; preferred time to be contacted.
- Step 3 contact information: name; phone number; email address; brief project description.
- Allow optional photo, drawing, or document uploads where technically supported. Keep the workflow short, accessible, and easy to complete on a phone. Use conditional fields so residential customers are not forced to answer commercial project questions.
- Clearly distinguish an estimate request from a confirmed appointment. Provide a useful success state after submission.
- Implement real form validation and a working submission pathway if the platform supports backend integration. If no backend or email service is configured, clearly label the form as a prototype and provide a functional alternative using the company's verified contact details. Do not falsely claim submissions are being delivered.
- Implement click-to-call links using the verified phone number; prominent estimate CTAs throughout the site; clear service-specific next steps; consistent contact information; accessible form labels and keyboard navigation; clear loading, validation, success, and error states; a persistent mobile contact CTA that does not obstruct content; and a clear distinction between residential and commercial enquiries.

## 7. Business facts, trust claims, and owner-verification boundaries — COMPLETE
- Use the existing website as source of truth for business information. Preserve accurate details and do not invent credentials, reviews, project outcomes, guarantees, awards, or service availability.
- Official site displays NYC Master Plumber License #2164 and Westchester County License #1733 and identifies the company as licensed and insured.
- Existing BuildZoom recognition must be described accurately and linked where possible. Attribute it as third-party, time-sensitive recognition; do not create certifications or ratings.
- Do not claim the existing website is losing leads or underperforming unless analytics demonstrate it.
- Do not claim a specific number of leads or revenue increase without supporting evidence.
- Identify any business details, testimonial approval, project details, and project photo provenance requiring owner verification before production use.
- Owner approval of project-photo provenance, project details, and testimonial quotations/attributions remains required before adopting the concept as the company's production website.

## 8. Live preview and functional quality — COMPLETE
- If the platform supports a live preview, provide a working preview URL.
- Test navigation, forms, responsive layouts, image loading, internal links, click-to-call actions, and all primary conversion pathways.
- Keep the design credible and premium for commercial-contract prospects while making residential service enquiries easy.
- Prioritize commercial project enquiries, clearer structured estimate requests, trust and project proof, easy residential enquiries, and mobile usability/accessibility/technical SEO.
- Preserve the existing company's identity and factual information while substantially improving the user experience.
- Before finishing, provide the live preview URL if available, a summary of the most important improvements, a list of features that are fully functional, integrations requiring configuration, and business details or project assets requiring owner verification.

## Delivery constraints
- The estimate flow is a prototype only: it validates locally and creates an email draft; it does not send to a backend or confirm an appointment. A backend/email integration is required if the business wants direct form submission.
- Project imagery is represented by clearly labeled replacement placeholders where provenance could not be verified. Owner review is needed before production use.
- The site is available in the live Preview; it has not been published to the company's production domain.
