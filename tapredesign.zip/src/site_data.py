"""Company information transcribed from the current official Tap Plumbing Corp website.

BuildZoom recognition is third-party and time-sensitive. Project cards reuse the
current site's published captions, but photos remain unverified placeholders.
"""

SITE_ORIGIN = "https://tapplumbingcorp.com"
SITE = {
    "name": "Tap Plumbing Corp",
    "phone": "718-337-8749",
    "phone_uri": "tel:17183378749",
    "email": "Office@tapplumbingcorp.com",
    "email_uri": "mailto:Office@tapplumbingcorp.com",
    "address": "3004 Middletown Rd Unit 3",
    "city": "Bronx",
    "region": "NY",
    "postal_code": "10461",
    "hours": "Monday–Friday, 9:00 a.m.–5:00 p.m.",
    "licenses": ["NYC Master Plumber License #2164", "Westchester County License #1733"],
    "service_areas": ["Bronx", "Manhattan", "Queens", "Brooklyn", "Westchester County"],
    "buildzoom_url": "https://www.buildzoom.com/contractor/tap-plumbing-corp",
}

NAV = [
    ("Services", "/services/"),
    ("Commercial Plumbing", "/services/commercial-plumbing/"),
    ("Projects", "/projects/"),
    ("About", "/about/"),
    ("Contact", "/contact/"),
]

SERVICES = [
    {
        "slug": "commercial-plumbing",
        "title": "Commercial Plumbing",
        "short": "Plumbing systems and project work for businesses, multi-family buildings, and commercial properties.",
        "intro": "Tap Plumbing Corp lists commercial plumbing for offices, retail spaces, multi-family buildings, and industrial properties across New York City and Westchester County.",
        "items": [
            "Multi-family and apartment building plumbing",
            "Office and retail space plumbing systems",
            "Backflow prevention and testing",
            "Commercial water heater installation",
            "Grease trap installation and maintenance",
            "NYC DOB permit and inspection coordination where applicable",
        ],
        "keywords": ["commercial plumbing NYC", "multi-family plumbing", "commercial plumber", "property manager plumbing"],
        "next": "Tell us about the property, project scope, and the best way to reach you. An estimate request is not a confirmed appointment.",
    },
    {
        "slug": "residential-plumbing",
        "title": "Residential Plumbing",
        "short": "Repair, installation, and renovation plumbing for homes.",
        "intro": "The company lists residential plumbing for homeowners, including repairs, installations, and renovation work in its stated service area.",
        "items": [
            "Faucet, fixture, and valve repair or replacement",
            "Toilet installation, repair, and replacement",
            "Pipe leak detection and repair",
            "Water supply line installation",
            "Kitchen and bathroom plumbing",
            "Code-conscious plumbing work for NYC and Westchester",
        ],
        "keywords": ["residential plumbing NYC", "home plumbing repair", "plumber Bronx", "plumbing installation"],
        "next": "Describe the issue or planned work, and include the property location so the team can discuss next steps.",
    },
    {
        "slug": "new-construction",
        "title": "New Construction Plumbing",
        "short": "Plumbing installation for new residential and commercial construction, from rough-in through finish.",
        "intro": "The official service page describes plumbing installation for new construction, including work from architectural plans and coordination with general contractors.",
        "items": [
            "Underground and above-grade rough-in",
            "Water service and meter installation",
            "Drain, waste, and vent systems",
            "Gas line installation and pressure testing",
            "Final fixture installation and trim-out",
            "NYC DOB permit filing and inspections where applicable",
        ],
        "keywords": ["new construction plumbing NYC", "construction plumber", "plumbing rough-in", "commercial construction plumbing"],
        "next": "Share the project location, stage, plans or scope, and any relevant contractor coordination needs.",
    },
    {
        "slug": "bathroom-kitchen-renovations",
        "title": "Kitchen & Bathroom Renovations",
        "short": "Plumbing rough-in, fixture installation, drain work, and final connections for renovation scopes.",
        "intro": "Tap Plumbing Corp describes kitchen and bathroom plumbing from rough-in to finish, including supply lines, drain rough-ins, fixture installation, and final connections.",
        "items": [
            "Bathroom plumbing rough-in and finish",
            "Shower, tub, and toilet installation",
            "Kitchen sink, faucet, and disposal installation",
            "Drain and vent stack work",
            "Fixture upgrades and replacements",
            "Coordination with general contractors and tile contractors",
        ],
        "keywords": ["bathroom plumbing renovation", "kitchen plumbing renovation", "plumbing rough-in NYC", "fixture installation"],
        "next": "Tell us which rooms are involved, the property location, and whether the work is planned or part of an active renovation.",
    },
    {
        "slug": "gas-piping",
        "title": "Gas Piping",
        "short": "Gas line installation, repair, and pressure testing as described by the company.",
        "intro": "The company lists gas piping among its residential and commercial plumbing services. Contact Tap Plumbing Corp to discuss the property and the specific scope.",
        "items": [
            "Gas piping installation",
            "Gas piping repair",
            "Pressure testing, as listed by the company",
            "Gas line work connected to new construction or renovation scopes",
        ],
        "keywords": ["gas piping NYC", "gas line installation", "gas piping repair", "licensed plumber gas piping"],
        "next": "Describe the appliance or piping scope and the property location. For urgent concerns, contact the company directly during its published office hours.",
    },
    {
        "slug": "fixture-installation",
        "title": "Fixture Installation",
        "short": "Installation of plumbing fixtures for homes and businesses.",
        "intro": "The company lists installation of faucets, toilets, showers, sinks, disposals, and other plumbing fixtures.",
        "items": [
            "Faucets and sinks",
            "Toilets and showers",
            "Bathroom vanities and plumbing fixtures",
            "Kitchen disposals and fixture connections",
            "Supply and drain connections as part of the installation scope",
        ],
        "keywords": ["plumbing fixture installation NYC", "faucet installation", "toilet installation", "sink installation"],
        "next": "Tell us which fixtures are involved, whether replacements or new connections are needed, and where the property is located.",
    },
    {
        "slug": "plumbing-repairs",
        "title": "Plumbing Repairs",
        "short": "Plumbing repair enquiries for common residential and commercial issues.",
        "intro": "The company lists plumbing repairs for residential and commercial customers. Share the issue and property location so the team can discuss the appropriate next step.",
        "items": [
            "Leak and pipe repair enquiries",
            "Burst pipe repair enquiries",
            "Running toilet repairs",
            "Low water pressure concerns",
            "Other plumbing repair scopes",
        ],
        "keywords": ["plumbing repairs NYC", "plumber for leaks", "pipe repair Bronx", "residential plumbing repair"],
        "next": "For immediate help, call 718-337-8749 during the published office hours. This website does not advertise 24/7 emergency service.",
    },
    {
        "slug": "water-heater-services",
        "title": "Water Heaters & Boilers",
        "short": "Installation, repair, and replacement enquiries for water heaters and boilers.",
        "intro": "The company lists installation, repair, and replacement of traditional and tankless water heaters and boilers for residential and commercial properties.",
        "items": [
            "Traditional water heater installation, repair, or replacement",
            "Tankless water heater installation, repair, or replacement",
            "Boiler installation, repair, or replacement enquiries",
            "Residential and commercial project discussions",
        ],
        "keywords": ["water heater plumber NYC", "boiler plumbing service", "tankless water heater", "water heater replacement"],
        "next": "Include the property location and, if known, the equipment type and whether the request is for repair, replacement, or a planned installation.",
    },
]

PROJECTS = [
    {
        "title": "Multi-Family Plumbing Installation",
        "location": "Brooklyn, NY",
        "scope": "Complete rough-in and fixture installation for a full residential building renovation.",
        "verify": "Project photo and details require owner verification before production use.",
    },
    {
        "title": "Pipe Installation & Replacement",
        "location": "Bronx, NY",
        "scope": "Full copper pipe replacement and new supply line installation for a residential property.",
        "verify": "Project photo and details require owner verification before production use.",
    },
    {
        "title": "Bathroom Renovation — Shower & Drain",
        "location": "Queens, NY",
        "scope": "Shower enclosure rough-in, drain work, and finish plumbing for a bathroom renovation.",
        "verify": "Project photo and details require owner verification before production use.",
    },
    {
        "title": "Kitchen Plumbing Renovation",
        "location": "Westchester County, NY",
        "scope": "New sink, faucet, and supply line installation as part of a kitchen remodel.",
        "verify": "Project photo and details require owner verification before production use.",
    },
    {
        "title": "Bathroom Fixture & Vanity Installation",
        "location": "Manhattan, NY",
        "scope": "Vanity, faucet, and fixture installation with new supply and drain connections.",
        "verify": "Project photo and details require owner verification before production use.",
    },
    {
        "title": "Residential Plumbing Repair",
        "location": "Bronx, NY",
        "scope": "On-site diagnosis and repair of a residential plumbing issue.",
        "verify": "Project photo and details require owner verification before production use.",
    },
]

TESTIMONIALS = [
    {
        "quote": "Tap Plumbing did a complete rough-in for our three-family renovation in the Bronx. Showed up on time, pulled the permits, passed inspection first try. Exactly what you want from a master plumber.",
        "name": "Marcus D.",
        "role": "Property Owner, Bronx NY",
    },
    {
        "quote": "We manage several commercial buildings in Westchester and Tap Plumbing is our go-to for anything beyond routine maintenance. Reliable, licensed, and they know the code.",
        "name": "Sandra R.",
        "role": "Property Manager, Westchester County",
    },
    {
        "quote": "Had a gas line run for a new stove and dryer. They handled the permit, did the pressure test, and had everything done in one day. Clean work, no surprises on the bill.",
        "name": "James T.",
        "role": "Homeowner, Queens NY",
    },
]

FAQS = [
    {
        "q": "What areas does Tap Plumbing Corp serve?",
        "a": "The company lists the Bronx, Manhattan, Queens, Brooklyn, and Westchester County. Contact the office to confirm service availability for a specific property address.",
    },
    {
        "q": "Do you handle commercial and residential plumbing?",
        "a": "Yes. The company lists both commercial and residential plumbing, alongside construction, renovation, gas piping, fixture, repair, water heater, and boiler work.",
    },
    {
        "q": "Can you work on new construction projects?",
        "a": "New construction plumbing is one of the company's listed services. Share the project location, stage, and scope to begin a discussion.",
    },
    {
        "q": "Can property managers request commercial plumbing estimates?",
        "a": "Yes. Property managers can use the estimate form or contact the office by phone or email to discuss a commercial property and its scope.",
    },
    {
        "q": "Do you coordinate permits and inspections?",
        "a": "The company's commercial and new-construction pages describe NYC DOB permit and inspection coordination or filing where applicable. Contact the team to discuss requirements for a specific project.",
    },
    {
        "q": "How can I request a plumbing estimate?",
        "a": "Call 718-337-8749, email Office@tapplumbingcorp.com, or use the estimate form. The form on this redesign concept prepares an email draft; it does not submit a request directly to the company.",
    },
    {
        "q": "What information should I provide about my project?",
        "a": "Include the property location, type of work, approximate scope, whether it is an urgent repair or a planned project, and the best way to contact you. For commercial or construction work, include any useful project or coordination details.",
    },
]

LOCATIONS = {
    "bronx": {
        "name": "Bronx",
        "title": "Plumbing Services in the Bronx",
        "meta_description": "Bronx plumbing for residential repairs, building work, and renovation projects. Tap Plumbing Corp lists its Bronx office and service area.",
        "intro": "Tap Plumbing Corp lists its business address in the Bronx and identifies the Bronx as part of its New York City service area.",
        "proof": "The current company website lists pipe installation and replacement and residential plumbing repair examples in the Bronx.",
        "focus": "Homeowners, building owners, and project teams can discuss repairs, renovations, multi-family plumbing, new construction, and other listed services.",
        "keywords": ["plumber Bronx NY", "Bronx plumbing contractor", "Bronx pipe repair", "Bronx commercial plumber"],
    },
    "manhattan": {
        "name": "Manhattan",
        "title": "Plumbing Services in Manhattan",
        "meta_description": "Tap Plumbing Corp lists Manhattan among its service areas and publishes a bathroom fixture and vanity installation example.",
        "intro": "Manhattan is included in the service-area information on Tap Plumbing Corp's current website.",
        "proof": "The current company website lists a bathroom fixture and vanity installation example in Manhattan.",
        "focus": "Discuss fixture installation, renovation plumbing, commercial work, or another listed service with the team and confirm availability for the property address.",
        "keywords": ["Manhattan plumbing contractor", "Manhattan plumber", "Manhattan fixture installation", "commercial plumbing Manhattan"],
    },
    "queens": {
        "name": "Queens",
        "title": "Plumbing Services in Queens",
        "meta_description": "Tap Plumbing Corp lists Queens service and a bathroom shower and drain renovation example. Contact the team to confirm a property address.",
        "intro": "Tap Plumbing Corp lists Queens among the New York City service areas on its current website.",
        "proof": "The current company website lists a bathroom shower and drain renovation example in Queens.",
        "focus": "Homeowners and project teams can ask about residential plumbing, kitchen and bathroom renovations, gas piping, repairs, and other listed services.",
        "keywords": ["Queens plumbing contractor", "Queens plumber", "Queens bathroom plumbing", "residential plumber Queens"],
    },
    "brooklyn": {
        "name": "Brooklyn",
        "title": "Plumbing Services in Brooklyn",
        "meta_description": "Tap Plumbing Corp lists Brooklyn service and a multi-family plumbing installation example. Ask about availability for a specific property.",
        "intro": "Brooklyn is included in Tap Plumbing Corp's current published service-area information.",
        "proof": "The current company website lists a multi-family plumbing installation example in Brooklyn.",
        "focus": "Contractors, property managers, and homeowners can discuss multi-family plumbing, new construction, renovations, repairs, and other listed services.",
        "keywords": ["Brooklyn plumbing contractor", "Brooklyn plumber", "multi-family plumbing Brooklyn", "residential plumbing Brooklyn"],
    },
    "westchester": {
        "name": "Westchester County",
        "title": "Plumbing Services in Westchester County",
        "meta_description": "Tap Plumbing Corp lists Westchester County service and county license #1733. Contact the team to confirm availability for a property.",
        "intro": "Tap Plumbing Corp lists Westchester County in its service area and displays Westchester County License #1733.",
        "proof": "The current company website lists a kitchen plumbing renovation example in Westchester County and includes a property-manager testimonial attributed to Westchester County.",
        "focus": "Homeowners, property managers, and businesses can discuss commercial plumbing, water heaters and boilers, renovations, gas piping, repairs, and other listed services.",
        "keywords": ["Westchester County plumber", "Westchester plumbing contractor", "commercial plumber Westchester", "Westchester renovation plumbing"],
    },
}
