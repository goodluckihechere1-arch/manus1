"""Shared HTML fragments and page shell for the generated static website."""

from datetime import datetime
from html import escape
import json
from .site_data import LOCATIONS, NAV, SERVICES, SITE, SITE_ORIGIN


def e(value):
    return escape(str(value), quote=True)


def route_url(route):
    if not route.startswith("/"):
        route = "/" + route
    return route if route.endswith("/") else route + "/"


def license_chips():
    return "".join(f'<span class="license-chip"><span class="chip-dot" aria-hidden="true"></span>{e(item)}</span>' for item in SITE["licenses"])


def header(active=""):
    links = []
    for label, url in NAV:
        current = ' aria-current="page"' if active == url else ""
        links.append(f'<a href="{url}"{current}>{e(label)}</a>')
    nav = "".join(links)
    estimate_current = ' aria-current="page"' if active == "/estimate/" else ""
    return f'''<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header">
  <div class="header-inner wrap">
    <a class="brand" href="/" aria-label="Tap Plumbing Corp home">
      <img src="/assets/tap-mark.svg" width="42" height="42" alt="" aria-hidden="true">
      <span class="brand-words"><strong>TAP</strong><span>PLUMBING CORP</span></span>
    </a>
    <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-nav" aria-label="Open navigation"><span></span><span></span></button>
    <nav class="primary-nav" id="primary-nav" aria-label="Main navigation">{nav}<a class="nav-estimate" href="/estimate/"{estimate_current}>Request an Estimate</a><a class="nav-phone" href="{SITE['phone_uri']}">{e(SITE['phone'])}</a></nav>
  </div>
</header>'''


def footer():
    service_links = "".join(f'<li><a href="/services/{s["slug"]}/">{e(s["title"])}</a></li>' for s in SERVICES)
    area_links = "".join(f'<li><a href="/areas/{slug}/">{e(data["name"])}</a></li>' for slug, data in LOCATIONS.items())
    return f'''<footer class="site-footer" id="contact-details">
  <div class="wrap footer-main">
    <div class="footer-brand">
      <a class="brand brand-footer" href="/" aria-label="Tap Plumbing Corp home"><img src="/assets/tap-mark.svg" width="42" height="42" alt="" aria-hidden="true"><span class="brand-words"><strong>TAP</strong><span>PLUMBING CORP</span></span></a>
      <p>Commercial, construction, and residential plumbing across New York City and Westchester County.</p>
      <div class="footer-licenses">{license_chips()}</div>
    </div>
    <div class="footer-column"><h2>Contact</h2><address>{e(SITE['address'])}<br>{e(SITE['city'])}, {e(SITE['region'])} {e(SITE['postal_code'])}</address><a href="{SITE['phone_uri']}">{e(SITE['phone'])}</a><a href="{SITE['email_uri']}">{e(SITE['email'])}</a><p class="footer-hours">Office hours<br>{e(SITE['hours'])}<br>Saturday and Sunday: Closed</p></div>
    <div class="footer-column"><h2>Services</h2><ul>{service_links}</ul></div>
    <div class="footer-column"><h2>Areas served</h2><ul>{area_links}</ul><a href="/areas/">View all service areas</a></div>
  </div>
  <div class="footer-bottom"><div class="wrap footer-bottom-inner"><span>© {datetime.now().year} Tap Plumbing Corp</span><span><a href="/privacy/">Privacy & prototype notice</a></span><span>Licensed and insured, as stated by the company</span></div></div>
</footer>
<div class="mobile-contact-bar" aria-label="Quick contact"><a href="{SITE['phone_uri']}" class="mobile-call" aria-label="Call Tap Plumbing Corp at {e(SITE['phone'])}">Call {e(SITE['phone'])}</a><a href="/estimate/" class="mobile-estimate">Request an Estimate</a></div>'''


def structured_business():
    address = {
        "@type": "PostalAddress",
        "streetAddress": SITE["address"],
        "addressLocality": SITE["city"],
        "addressRegion": SITE["region"],
        "postalCode": SITE["postal_code"],
        "addressCountry": "US",
    }
    data = {
        "@context": "https://schema.org",
        "@type": "Plumber",
        "name": SITE["name"],
        "url": SITE_ORIGIN + "/",
        "telephone": SITE["phone"],
        "email": SITE["email"],
        "address": address,
        "areaServed": SITE["service_areas"],
        "openingHours": ["Mo-Fr 09:00-17:00"],
        "sameAs": [SITE["buildzoom_url"]],
    }
    return json.dumps(data, ensure_ascii=False).replace("</", "<\\/")


def shell(route, title, description, content, active="", keywords=None, schema=None):
    path = route_url(route)
    full_title = title if "Tap Plumbing Corp" in title else f"{title} | Tap Plumbing Corp"
    canonical = SITE_ORIGIN + path
    keyword_values = keywords or ["plumbing contractor NYC", "commercial plumbing", "residential plumbing", "new construction plumbing"]
    keyword_meta = ", ".join(keyword_values[:8])
    schemas = [f'<script type="application/ld+json">{structured_business()}</script>']
    if schema:
        schemas.append(f'<script type="application/ld+json">{json.dumps(schema, ensure_ascii=False).replace("</", "<\\/")}</script>')
    return f'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#132b3a">
  <title>{e(full_title)}</title>
  <meta name="description" content="{e(description)}">
  <meta name="keywords" content="{e(keyword_meta)}">
  <link rel="canonical" href="{e(canonical)}">
  <link rel="icon" href="/assets/tap-mark.svg" type="image/svg+xml">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Source+Sans+3:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/site.css">
  <meta property="og:type" content="website">
  <meta property="og:title" content="{e(full_title)}">
  <meta property="og:description" content="{e(description)}">
  <meta property="og:url" content="{e(canonical)}">
  <meta property="og:site_name" content="Tap Plumbing Corp">
  <meta property="og:image" content="{SITE_ORIGIN}/assets/social-card.svg">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="{e(full_title)}">
  <meta name="twitter:description" content="{e(description)}">
  <meta name="twitter:image" content="{SITE_ORIGIN}/assets/social-card.svg">
  {''.join(schemas)}
</head>
<body>
{header(active)}
<main id="main">{content}</main>
{footer()}
<script src="/assets/site.js" defer></script>
</body>
</html>'''


def eyebrow(number, label):
    return f'<div class="eyebrow"><span class="eyebrow-number">{e(number)}</span><span>{e(label)}</span></div>'


def service_card(service, index=1):
    return f'''<article class="service-card"><div class="service-card-top"><span class="card-index">{index:02d}</span><span class="card-arrow" aria-hidden="true">↗</span></div><h3><a href="/services/{service['slug']}/">{e(service['title'])}</a></h3><p>{e(service['short'])}</p><a class="text-link" href="/services/{service['slug']}/">Explore service <span aria-hidden="true">→</span></a></article>'''


def project_card(project, index):
    return f'''<article class="project-card" id="project-{index}">
  <div class="project-placeholder" role="img" aria-label="Project photo placeholder for {e(project['title'])} in {e(project['location'])}"><span class="placeholder-kicker">Project image</span><span class="placeholder-line" aria-hidden="true"></span><span class="placeholder-note">Photo pending<br>owner verification</span><span class="placeholder-index">{index:02d}</span></div>
  <div class="project-info"><span class="project-location">{e(project['location'])}</span><h3>{e(project['title'])}</h3><p>{e(project['scope'])}</p><p class="verification-note">{e(project['verify'])}</p></div>
</article>'''


def cta_band(title="Planning a Plumbing Project?", text="Homeowners, contractors, and property managers can share the project requirements to start a conversation.", commercial=False):
    query = "?type=commercial" if commercial else ""
    return f'''<section class="cta-band"><div class="wrap cta-band-inner"><div><p class="eyebrow eyebrow-light"><span class="eyebrow-number">→</span><span>Start a conversation</span></p><h2>{e(title)}</h2><p>{e(text)}</p></div><div class="cta-band-actions"><a class="button button-light" href="/estimate/{query}">Request an Estimate <span aria-hidden="true">→</span></a><a class="button button-outline-light" href="{SITE['phone_uri']}">Call {e(SITE['phone'])}</a></div></div></section>'''
