"""Generate a self-contained, SEO-readable static website with Python's stdlib."""

from datetime import datetime
from html import escape
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "dist"
ASSETS = Path(__file__).resolve().parent / "assets"
from .site_data import FAQS, LOCATIONS, PROJECTS, SERVICES, SITE, SITE_ORIGIN, TESTIMONIALS  # noqa: E402
from .site_templates import cta_band, eyebrow, e, license_chips, project_card, route_url, service_card, shell  # type: ignore[reportMissingImports]  # noqa: E402


def section_title(number, label, title, copy=""):
    return f'''<div class="section-heading">{eyebrow(number, label)}<div><h2>{e(title)}</h2>{f'<p>{e(copy)}</p>' if copy else ''}</div></div>'''


def service_schema(service):
    return {
        "@context": "https://schema.org",
        "@type": "Service",
        "name": service["title"],
        "description": service["short"],
        "provider": {"@type": "Plumber", "name": SITE["name"], "url": SITE_ORIGIN + "/"},
        "areaServed": SITE["service_areas"],
    }


def list_services(items):
    return "".join(f"<li>{e(item)}</li>" for item in items)


def home_page():
    commercial = next(item for item in SERVICES if item["slug"] == "commercial-plumbing")
    residential = next(item for item in SERVICES if item["slug"] == "residential-plumbing")
    service_html = "".join(service_card(service, i) for i, service in enumerate(SERVICES, start=1))
    projects = "".join(project_card(item, i) for i, item in enumerate(PROJECTS, start=1))
    reviews = "".join(f'''<figure class="quote-card"><span class="quote-mark" aria-hidden="true">“</span><blockquote>{e(item['quote'])}</blockquote><figcaption><strong>{e(item['name'])}</strong><span>{e(item['role'])}</span></figcaption></figure>''' for item in TESTIMONIALS)
    faqs = "".join(f'<details class="faq-item"><summary>{e(item["q"])}<span aria-hidden="true"></span></summary><p>{e(item["a"])}</p></details>' for item in FAQS)
    content = f'''<section class="hero"><div class="wrap hero-inner"><div class="hero-copy"><p class="hero-kicker"><span class="status-dot"></span>Licensed Master Plumber · NYC & Westchester</p><h1>Professional plumbing for <em>buildings, businesses & homes.</em></h1><p class="hero-lede">From commercial plumbing and new construction to residential repairs and renovations, Tap Plumbing Corp serves customers across New York City and Westchester County.</p><div class="hero-actions"><a class="button button-primary" href="/estimate/">Request a Project Estimate <span aria-hidden="true">→</span></a><a class="button button-quiet" href="{SITE['phone_uri']}">Call {e(SITE['phone'])}</a></div><div class="hero-licenses">{''.join(f'<span>{e(x)}</span>' for x in SITE['licenses'])}</div></div><div class="hero-diagram" role="img" aria-label="Illustrative line diagram representing plumbing systems, not a photograph of a Tap Plumbing Corp project"><div class="diagram-label diagram-label-top">SYSTEMS / NYC + WESTCHESTER</div><svg viewBox="0 0 600 620" aria-hidden="true" focusable="false"><path class="pipe pipe-muted" d="M112 52v142q0 18 18 18h82v184q0 18 18 18h151q18 0 18-18V198q0-18 18-18h82V52"/><path class="pipe pipe-blue" d="M208 52v111q0 18 18 18h74v286q0 18 18 18h79"/><path class="pipe pipe-light" d="M483 52v258q0 18-18 18h-59v170"/><path class="pipe pipe-outline" d="M112 423h70q18 0 18 18v108q0 18 18 18h238"/><circle class="pipe-joint" cx="212" cy="212" r="13"/><circle class="pipe-joint" cx="420" cy="414" r="13"/><circle class="pipe-joint" cx="482" cy="328" r="13"/><path class="diagram-tick" d="M82 120h29M82 340h29M498 113h33M498 490h33"/><text x="57" y="110">01 / WATER</text><text x="507" y="101">02 / DWV</text><text x="505" y="485">03 / GAS</text></svg><div class="diagram-stamp"><strong>NYC</strong><span>LICENSE #2164</span><i></i><strong>WC</strong><span>LICENSE #1733</span></div><div class="diagram-foot">Illustrative plumbing-system drawing<br>Not a project photograph</div></div></div></section>
<section class="trust-ribbon"><div class="wrap trust-inner"><span class="trust-label">Licensed & insured<br><small>as stated by the company</small></span><span class="trust-item"><strong>NYC #2164</strong><small>Master Plumber License</small></span><span class="trust-item"><strong>Westchester #1733</strong><small>County license</small></span><a class="trust-item trust-buildzoom" href="{SITE['buildzoom_url']}" target="_blank" rel="noopener noreferrer"><strong>BuildZoom ↗</strong><small>Profile currently lists score 112 and top 3%* </small></a></div><p class="wrap trust-footnote">*Third-party BuildZoom profile information; rankings and scores may change. <a href="{SITE['buildzoom_url']}" target="_blank" rel="noopener noreferrer">View source</a>.</p></section>
<section class="pathways section-pad"><div class="wrap">{section_title('01', 'Choose your project path', 'Start with the work you need.', 'The right next step depends on whether you are planning a building project or need plumbing work at home.') }<div class="pathway-grid"><article class="pathway-card pathway-commercial"><span class="pathway-index">01 / COMMERCIAL</span><h3>Commercial & construction plumbing</h3><p>For general contractors, property managers, building owners, and businesses coordinating construction or renovation work.</p><ul><li>New construction and system installation</li><li>Multi-family and commercial buildings</li><li>Renovation plumbing and coordination</li></ul><a class="button button-primary" href="/estimate/?type=commercial&service=commercial-plumbing">Discuss a Commercial Project <span aria-hidden="true">→</span></a></article><article class="pathway-card pathway-residential"><span class="pathway-index">02 / RESIDENTIAL</span><h3>Residential plumbing</h3><p>For homeowners planning repairs, fixture work, renovations, or equipment installation.</p><ul><li>Repairs, fixtures, and piping</li><li>Kitchen and bathroom renovations</li><li>Gas piping, water heaters, and boilers</li></ul><a class="button button-outline" href="/estimate/?type=residential&service=residential-plumbing">Request Residential Service <span aria-hidden="true">→</span></a></article></div></div></section>
<section class="commercial-feature section-pad"><div class="wrap commercial-inner"><div class="commercial-copy">{eyebrow('02', 'Commercial capabilities')}<h2>Built around the needs of a project team.</h2><p>The company lists plumbing for offices, retail, multi-family buildings, and industrial properties, alongside new construction and renovation work.</p><a class="text-link text-link-light" href="/services/commercial-plumbing/">Explore commercial plumbing <span aria-hidden="true">→</span></a></div><div class="commercial-detail"><div class="capability-row"><span>01</span><div><h3>Plan the scope</h3><p>Share the property type, project stage, and work being considered.</p></div></div><div class="capability-row"><span>02</span><div><h3>Coordinate the work</h3><p>The company's published service pages describe coordination with general contractors and permit/inspection work where applicable.</p></div></div><div class="capability-row"><span>03</span><div><h3>Discuss next steps</h3><p>Use the estimate workflow to outline the project and contact preferences. An estimate request is not a booked appointment.</p></div></div><a class="button button-light" href="/estimate/?type=commercial&service=commercial-plumbing">Discuss a Commercial Project <span aria-hidden="true">→</span></a></div></div></section>
<section class="projects-preview section-pad"><div class="wrap">{section_title('03', 'Company-listed project examples', 'Project work, presented transparently.', 'The current company website lists these project types, locations, and scopes. Photos are intentionally held for owner verification; no placeholder is presented as completed Tap Plumbing Corp work.') }<div class="project-grid">{projects}</div><div class="section-bottom"><span class="section-footnote">Project captions are transcribed from the current company website. Confirm scope, location, and image rights before production use.</span><a class="text-link" href="/projects/">View project examples <span aria-hidden="true">→</span></a></div></div></section>
 <section class="services-section section-pad"><div class="wrap">{section_title('04', 'Services', 'Plumbing services, clearly organized.', 'Explore the services listed by the company and choose the page that best fits your project.') }<div class="services-grid">{service_html}</div><div class="section-bottom"><a class="text-link" href="/services/">View all services <span aria-hidden="true">→</span></a></div></div></section>
<section class="process-section section-pad"><div class="wrap">{section_title('05', 'How to begin', 'Three clear steps to a project conversation.') }<div class="process-grid"><article><span class="process-number">01</span><h3>Tell us what you need</h3><p>Describe the plumbing issue or project, property location, and who should be contacted.</p></article><article><span class="process-number">02</span><h3>Discuss the scope</h3><p>Share approximate requirements and request an estimate. No delivery timeframe is promised here.</p></article><article><span class="process-number">03</span><h3>Coordinate next steps</h3><p>Continue the conversation with the Tap Plumbing Corp team by email or phone.</p></article></div></div></section>
<section class="reviews-section section-pad"><div class="wrap">{section_title('06', 'Customer comments', 'What customers say.', 'Testimonials reproduced from the current company website, with the published wording and attributions.') }<div class="quote-grid">{reviews}</div><p class="section-footnote review-note">Quotes and attributions should be reconfirmed by the business before the redesign is used in production.</p></div></section>
<section class="faq-section section-pad"><div class="wrap faq-wrap">{section_title('07', 'Frequently asked questions', 'Useful answers before you reach out.') }<div class="faq-list">{faqs}</div></div></section>
{cta_band()}
'''
    return shell("/", "Plumbing in NYC & Westchester", "Commercial, construction, and residential plumbing across NYC and Westchester County. Request an estimate or call Tap Plumbing Corp.", content, active="", keywords=["plumbing contractor NYC", "commercial plumbing NYC", "residential plumbing NYC", "new construction plumbing", "gas piping", "plumbing repairs"])


def services_index():
    cards = "".join(service_card(service, i) for i, service in enumerate(SERVICES, start=1))
    content = f'''<section class="page-hero page-hero-compact"><div class="wrap page-hero-inner">{eyebrow('01', 'Services')}<h1>Plumbing services for projects of every scale.</h1><p>Tap Plumbing Corp lists commercial and residential plumbing, new construction, renovations, gas piping, fixture installation, repairs, water heaters, and boilers.</p><div class="hero-actions"><a class="button button-primary" href="/estimate/">Request an Estimate <span aria-hidden="true">→</span></a><a class="button button-quiet" href="{SITE['phone_uri']}">Call {e(SITE['phone'])}</a></div></div></section><section class="section-pad"><div class="wrap"><div class="services-grid">{cards}</div></div></section>{cta_band()}'''
    return shell("/services/", "Plumbing Services", "Explore commercial, residential, new construction, renovation, gas piping, fixture, repair, water heater, and boiler services listed by Tap Plumbing Corp.", content, active="/services/", keywords=["plumbing services NYC", "commercial plumbing", "residential plumbing", "gas piping"])


def service_detail(service):
    items = list_services(service["items"])
    page_types = {
        "commercial-plumbing": "commercial",
        "residential-plumbing": "residential",
        "new-construction": "construction",
        "bathroom-kitchen-renovations": "renovation",
    }
    project_type = page_types.get(service["slug"])
    type_param = f"type={project_type}&" if project_type else ""
    estimate_url = f"/estimate/?{type_param}service={service['slug']}"
    commercial_note = "<p class=\"service-note\">Permit filing, inspection coordination, and contractor coordination are described on the company's current service pages where applicable. Discuss project-specific requirements directly with the team.</p>" if service["slug"] in ("commercial-plumbing", "new-construction") else ""
    content = f'''<section class="page-hero page-hero-compact"><div class="wrap page-hero-inner">{eyebrow('01', 'Service / '+service['title'])}<h1>{e(service['title'])} across NYC and Westchester.</h1><p>{e(service['intro'])}</p><div class="hero-actions"><a class="button button-primary" href="{estimate_url}">Request an Estimate <span aria-hidden="true">→</span></a><a class="button button-quiet" href="{SITE['phone_uri']}">Call {e(SITE['phone'])}</a></div></div></section><section class="section-pad service-detail"><div class="wrap service-detail-grid"><div>{eyebrow('02', 'Service scope')}<h2>What the company lists</h2><p>{e(service['short'])}</p>{commercial_note}</div><div class="service-list-panel"><ul class="check-list">{items}</ul></div></div></section><section class="service-next"><div class="wrap service-next-inner"><div><p class="eyebrow">Next step</p><h2>Start with the property and the scope.</h2><p>{e(service['next'])}</p></div><a class="button button-primary" href="{estimate_url}">Discuss this service <span aria-hidden="true">→</span></a></div></section><section class="section-pad related-services"><div class="wrap">{section_title('03', 'Related services', 'Explore other plumbing work.') }<div class="services-grid">{''.join(service_card(s, i) for i, s in enumerate([x for x in SERVICES if x['slug'] != service['slug']][:3], start=1))}</div></div></section>{cta_band()}'''
    desc = f"{service['title']} from Tap Plumbing Corp in NYC and Westchester. Review the listed scope and request an estimate."
    return shell(f"/services/{service['slug']}/", service["title"], desc, content, active="/services/", keywords=service["keywords"], schema=service_schema(service))


def projects_page():
    cards = "".join(project_card(item, i) for i, item in enumerate(PROJECTS, start=1))
    content = f'''<section class="page-hero page-hero-compact"><div class="wrap page-hero-inner">{eyebrow('01', 'Project examples')}<h1>Project categories published by the company.</h1><p>These examples and scopes are transcribed from the current Tap Plumbing Corp website. Photos and any case-study details require owner verification. This concept does not use illustrative images as project evidence.</p></div></section><section class="section-pad"><div class="wrap project-grid">{cards}</div></section><section class="verification-banner"><div class="wrap verification-banner-inner"><span class="verification-icon" aria-hidden="true">i</span><p>Before publishing this portfolio, confirm each location and scope, supply approved photos, and provide any additional case-study details. No detailed case-study links are shown because the current site does not provide them.</p></div></section>{cta_band("Planning a similar project?", "Share the property type, location, scope, and the best way to reach you.", commercial=True)}'''
    return shell("/projects/", "Plumbing Project Examples", "Project categories and scopes currently published by Tap Plumbing Corp, presented with photo placeholders pending owner verification.", content, active="/projects/", keywords=["plumbing projects NYC", "multi-family plumbing", "plumbing installation", "bathroom renovation plumbing"])


def about_page():
    reviews = "".join(f'''<figure class="quote-card"><span class="quote-mark" aria-hidden="true">“</span><blockquote>{e(item['quote'])}</blockquote><figcaption><strong>{e(item['name'])}</strong><span>{e(item['role'])}</span></figcaption></figure>''' for item in TESTIMONIALS)
    content = f'''<section class="page-hero page-hero-compact"><div class="wrap page-hero-inner">{eyebrow('01', 'About Tap Plumbing Corp')}<h1>Licensed plumbing for buildings, businesses, and homes.</h1><p>The company describes itself as licensed and insured and publishes plumbing service information for residential, commercial, construction, renovation, and gas piping work across NYC and Westchester County.</p></div></section><section class="section-pad"><div class="wrap about-facts"><article><p class="eyebrow">Credentials published by the company</p><h2>Licensing and service area.</h2><div class="license-stack">{license_chips()}</div><p>Tap Plumbing Corp lists its office in the Bronx and its service area across the Bronx, Manhattan, Queens, Brooklyn, and Westchester County. Confirm availability for a specific address by phone or email.</p><a class="text-link" href="/areas/">Explore service areas <span aria-hidden="true">→</span></a></article><article class="third-party-card"><p class="eyebrow">Third-party profile</p><h2>BuildZoom listing</h2><p>The public profile currently lists BuildZoom score 112 and a top 3% ranking among New York licensed contractors. These third-party figures can change and are not a Tap Plumbing Corp certification.</p><a class="text-link" href="{SITE['buildzoom_url']}" target="_blank" rel="noopener noreferrer">View the BuildZoom source <span aria-hidden="true">↗</span></a></article></div></section><section class="reviews-section section-pad"><div class="wrap">{section_title('02', 'Customer comments', 'Comments published on the current site.') }<div class="quote-grid">{reviews}</div><p class="section-footnote">Testimonials and attributions are reproduced as published on the current company website; confirm approval before production use.</p></div></section>{cta_band()}'''
    return shell("/about/", "About Tap Plumbing Corp | NYC & Westchester", "Learn about Tap Plumbing Corp's published licenses, service area, and third-party profile. Call or email to discuss a property.", content, active="/about/", keywords=["Tap Plumbing Corp", "licensed plumber NYC", "licensed plumber Westchester", "plumbing contractor Bronx"])


def contact_page():
    content = f'''<section class="page-hero page-hero-compact"><div class="wrap page-hero-inner">{eyebrow('01', 'Contact')}<h1>Tell us what the property needs.</h1><p>Contact Tap Plumbing Corp about residential plumbing, commercial work, new construction, or renovations. Office hours are Monday through Friday, 9:00 a.m. to 5:00 p.m.; the company lists weekends as closed.</p><div class="hero-actions"><a class="button button-primary" href="/estimate/">Request an Estimate <span aria-hidden="true">→</span></a><a class="button button-quiet" href="{SITE['phone_uri']}">Call {e(SITE['phone'])}</a></div></div></section><section class="section-pad contact-details"><div class="wrap contact-grid"><article class="contact-card"><p class="eyebrow">Call</p><h2><a href="{SITE['phone_uri']}">{e(SITE['phone'])}</a></h2><p>Click to call from a mobile phone.</p></article><article class="contact-card"><p class="eyebrow">Email</p><h2><a href="{SITE['email_uri']}">{e(SITE['email'])}</a></h2><p>Use email for project details or to continue an estimate request.</p></article><article class="contact-card"><p class="eyebrow">Office</p><h2>{e(SITE['address'])}</h2><p>{e(SITE['city'])}, {e(SITE['region'])} {e(SITE['postal_code'])}</p><a href="https://maps.google.com/?q=3004+Middletown+Rd+Unit+3+Bronx+NY" target="_blank" rel="noopener noreferrer">Get directions ↗</a></article><article class="contact-card"><p class="eyebrow">Office hours</p><h2>Weekdays</h2><p>{e(SITE['hours'])}<br>Saturday and Sunday: Closed</p></article></div></section>{cta_band()}'''
    return shell("/contact/", "Contact Tap Plumbing Corp | NYC & Westchester", "Call, email, or request an estimate from Tap Plumbing Corp. See the Bronx office address and weekday hours.", content, active="/contact/", keywords=["contact Tap Plumbing Corp", "plumber phone Bronx", "plumbing estimate NYC", "plumber Westchester"])


def estimate_form():
    types = [
        ("commercial", "Commercial property", "Offices, retail, and other business properties"),
        ("construction", "New construction", "New residential or commercial build"),
        ("multifamily", "Multi-family building", "Apartment or multi-unit property"),
        ("residential", "Residential repair", "Repair work at a home"),
        ("renovation", "Kitchen or bathroom renovation", "Planned remodel or fixture work"),
        ("other", "Other plumbing project", "Another plumbing scope"),
    ]
    type_cards = "".join(f'''<label class="project-type-option"><input type="radio" name="projectType" value="{value}" required><span class="project-type-body"><strong>{e(label)}</strong><small>{e(note)}</small></span><span class="radio-mark" aria-hidden="true"></span></label>''' for value, label, note in types)
    services = "".join(f'<option value="{e(service["title"])}" data-service-slug="{service["slug"]}">{e(service["title"])}</option>' for service in SERVICES)
    locations = "".join(f'<option value="{e(location)}">{e(location)}</option>' for location in SITE["service_areas"])
    return f'''<section class="page-hero page-hero-compact estimate-intro"><div class="wrap page-hero-inner">{eyebrow('01', 'Estimate request')}<h1>Tell us about your plumbing project.</h1><p>This prototype helps organize the project details and opens an email draft to Tap Plumbing Corp. It does not submit to a backend or confirm an appointment.</p><div class="estimate-disclaimer"><strong>Prototype contact pathway</strong><span>Before sending your request, review the email draft and send it from your email app. Selected files stay on your device and must be attached manually.</span></div></div></section><section class="section-pad estimate-section"><div class="wrap estimate-layout"><div class="estimate-aside"><p class="eyebrow">Project enquiry</p><h2>A few details help start the conversation.</h2><p>For a direct enquiry, call <a href="{SITE['phone_uri']}">{e(SITE['phone'])}</a> during the company's published weekday office hours, or email <a href="{SITE['email_uri']}">{e(SITE['email'])}</a>.</p><div class="stepper" aria-label="Estimate request steps"><div class="stepper-item is-active" data-step-indicator="1"><span>01</span><strong>Project type</strong></div><div class="stepper-item" data-step-indicator="2"><span>02</span><strong>Scope</strong></div><div class="stepper-item" data-step-indicator="3"><span>03</span><strong>Contact</strong></div></div><p class="section-footnote">An estimate request is not a confirmed appointment. The company lists office hours Monday–Friday, 9:00 a.m.–5:00 p.m.</p></div><div class="estimate-form-card"><form id="estimate-form" novalidate>
<fieldset class="form-step is-active" data-form-step="1"><legend>What kind of project is this?</legend><p class="form-step-intro">Choose the closest match. You can add detail in the next step.</p><div class="project-type-grid">{type_cards}</div><p class="field-error" data-error-for="projectType" aria-live="polite"></p><div class="form-actions"><span></span><button class="button button-primary" type="button" data-next-step>Continue <span aria-hidden="true">→</span></button></div></fieldset>
<fieldset class="form-step" data-form-step="2" hidden><legend>Tell us about the work.</legend><p class="form-step-intro">The details shown here are shared with the email draft you create on the final step.</p><div class="form-grid"><div class="field"><label for="service">Which plumbing service is required? <span aria-hidden="true">*</span></label><select id="service" name="service" required><option value="">Choose a service</option>{services}</select><p class="field-error" data-error-for="service" aria-live="polite"></p></div><div class="field"><label for="location">Where is the property located? <span aria-hidden="true">*</span></label><select id="location" name="location" required><option value="">Choose an area</option>{locations}<option value="Other / please confirm">Other / please confirm</option></select><p class="field-error" data-error-for="location" aria-live="polite"></p></div><div class="field"><label for="urgency">Is this an urgent repair or a planned project? <span aria-hidden="true">*</span></label><select id="urgency" name="urgency" required><option value="">Choose one</option><option>Urgent repair enquiry</option><option>Planned project</option><option>Exploring options</option></select><p class="field-error" data-error-for="urgency" aria-live="polite"></p></div><div class="field"><label for="preferred-contact">Preferred time to be contacted <span aria-hidden="true">*</span></label><select id="preferred-contact" name="preferredContact" required><option value="">Choose a preference</option><option>Morning</option><option>Afternoon</option><option>No preference</option></select><p class="field-error" data-error-for="preferredContact" aria-live="polite"></p></div><div class="field field-full"><label for="scope">Approximate project scope <span aria-hidden="true">*</span></label><textarea id="scope" name="scope" rows="3" maxlength="700" required placeholder="What work are you considering? For a commercial project, include useful building or coordination details."></textarea><p class="field-error" data-error-for="scope" aria-live="polite"></p></div><div class="field field-full conditional-commercial" hidden><label for="commercial-details">Building, project phase, or coordination details</label><textarea id="commercial-details" name="commercialDetails" rows="3" maxlength="500" placeholder="Optional details for commercial, multi-family, or new construction projects."></textarea><p class="field-hint">Optional. Residential repair enquiries can skip this field.</p></div><div class="field field-full"><label for="attachments">Optional photo, drawing, or document</label><input id="attachments" name="attachments" type="file" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx" multiple><p class="field-hint">Files are not uploaded by this prototype. If you use them, attach them manually after your email draft opens.</p><p class="selected-files" id="selected-files" aria-live="polite"></p></div></div><div class="form-actions"><button class="button button-outline" type="button" data-previous-step>Back</button><button class="button button-primary" type="button" data-next-step>Continue <span aria-hidden="true">→</span></button></div></fieldset>
<fieldset class="form-step" data-form-step="3" hidden><legend>How can the team reach you?</legend><p class="form-step-intro">Your details will be placed in an email draft addressed to the company. Nothing is sent automatically.</p><div class="form-grid"><div class="field"><label for="name">Name <span aria-hidden="true">*</span></label><input id="name" name="name" type="text" autocomplete="name" maxlength="100" required><p class="field-error" data-error-for="name" aria-live="polite"></p></div><div class="field"><label for="phone">Phone number <span aria-hidden="true">*</span></label><input id="phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" maxlength="35" required><p class="field-error" data-error-for="phone" aria-live="polite"></p></div><div class="field field-full"><label for="email">Email address <span aria-hidden="true">*</span></label><input id="email" name="email" type="email" autocomplete="email" maxlength="150" required><p class="field-error" data-error-for="email" aria-live="polite"></p></div><div class="field field-full"><label for="description">Brief project description <span aria-hidden="true">*</span></label><textarea id="description" name="description" rows="4" maxlength="1200" required placeholder="Anything else the Tap Plumbing Corp team should know?"></textarea><p class="field-error" data-error-for="description" aria-live="polite"></p></div></div><div class="form-actions"><button class="button button-outline" type="button" data-previous-step>Back</button><button class="button button-primary" type="submit">Prepare email draft <span aria-hidden="true">→</span></button></div></fieldset>
<div class="form-status" id="form-status" role="status" aria-live="polite" hidden></div><p class="form-note">Required fields are marked with an asterisk. This form does not book an appointment or send your information to Tap Plumbing Corp.</p></form></div></div></section>'''


def estimate_page():
    content = estimate_form()
    return shell("/estimate/", "Request a Plumbing Project Estimate", "Share project, location, scope, and contact details. This prototype prepares an email draft; it does not submit a request.", content, active="/estimate/", keywords=["request plumbing estimate", "commercial plumbing estimate", "residential plumbing estimate", "plumbing project contact"])


def areas_index():
    cards = []
    for slug, area in LOCATIONS.items():
        cards.append(f'''<article class="area-card"><span class="card-index">AREA / {e(slug[:3].upper())}</span><h2><a href="/areas/{slug}/">{e(area['name'])}</a></h2><p>{e(area['intro'])}</p><a class="text-link" href="/areas/{slug}/">View area details <span aria-hidden="true">→</span></a></article>''')
    content = f'''<section class="page-hero page-hero-compact"><div class="wrap page-hero-inner">{eyebrow('01', 'Areas served')}<h1>NYC and Westchester County.</h1><p>The current company website lists service across the Bronx, Manhattan, Queens, Brooklyn, and Westchester County. Contact the office to confirm availability for a specific property address.</p></div></section><section class="section-pad"><div class="wrap area-grid">{''.join(cards)}</div></section>{cta_band()}'''
    return shell("/areas/", "Tap Plumbing Corp Service Areas", "Tap Plumbing Corp lists service across the Bronx, Manhattan, Queens, Brooklyn, and Westchester County. Confirm a specific address by phone or email.", content, active="", keywords=["plumber service areas NYC", "plumbing Westchester County", "Bronx plumbing", "Queens plumbing"])


def area_page(slug, area):
    related = "".join(service_card(s, i) for i, s in enumerate(SERVICES[:4], start=1))
    content = f'''<section class="page-hero page-hero-compact"><div class="wrap page-hero-inner">{eyebrow('01', 'Service area / '+area['name'])}<h1>{e(area['title'])}</h1><p>{e(area['intro'])} Confirm service availability for a specific address with the company.</p><div class="hero-actions"><a class="button button-primary" href="/estimate/?area={slug}">Request an Estimate <span aria-hidden="true">→</span></a><a class="button button-quiet" href="{SITE['phone_uri']}">Call {e(SITE['phone'])}</a></div></div></section><section class="section-pad area-context"><div class="wrap area-context-grid"><article><p class="eyebrow">Published company example</p><h2>Locally relevant project context</h2><p>{e(area['proof'])}</p><p class="section-footnote">The example is transcribed from the current company website. Confirm the project details and image rights with the business before production use.</p></article><article><p class="eyebrow">Start with the scope</p><h2>Discuss your property or project.</h2><p>{e(area['focus'])}</p><a class="text-link" href="/estimate/?area={slug}">Share project details <span aria-hidden="true">→</span></a></article></div></section><section class="section-pad related-services"><div class="wrap">{section_title('02', 'Listed services', 'Explore plumbing services.') }<div class="services-grid">{related}</div></div></section>{cta_band()}'''
    return shell(f"/areas/{slug}/", area["title"], area["meta_description"], content, active="", keywords=area["keywords"])


def privacy_page():
    content = f'''<section class="page-hero page-hero-compact"><div class="wrap page-hero-inner">{eyebrow('01', 'Privacy & prototype notice')}<h1>How this estimate concept works.</h1><p>This page describes the estimate workflow included in this redesign concept. It is not a full legal privacy policy for a production website.</p></div></section><section class="section-pad"><div class="wrap prose"><h2>Estimate form</h2><p>The form runs in your browser and prepares an email draft to <a href="{SITE['email_uri']}">{e(SITE['email'])}</a>. It does not submit information to a Tap Plumbing Corp server. You must review and send the draft yourself. Optional files are not uploaded; attach them manually in your email application.</p><h2>Before production</h2><p>The business should approve and publish a complete privacy notice that reflects its chosen analytics, email, file-handling, and lead-management services before the website is used to collect enquiries.</p><p>For direct contact, call <a href="{SITE['phone_uri']}">{e(SITE['phone'])}</a> or email <a href="{SITE['email_uri']}">{e(SITE['email'])}</a>.</p></div></section>'''
    return shell("/privacy/", "Privacy & Prototype Notice", "A clear explanation of the estimate-request prototype and the production privacy notice still required.", content, active="", keywords=["estimate form privacy", "Tap Plumbing Corp contact", "plumbing estimate prototype"])


def write_page(route, document):
    target = OUT / route.strip("/") / "index.html" if route != "/" else OUT / "index.html"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(document, encoding="utf-8")


def build():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    pages = [("/", home_page())]
    pages.extend([
        ("/services/", services_index()),
        ("/projects/", projects_page()),
        ("/about/", about_page()),
        ("/contact/", contact_page()),
        ("/estimate/", estimate_page()),
        ("/areas/", areas_index()),
        ("/privacy/", privacy_page()),
    ])
    pages.extend((f"/services/{service['slug']}/", service_detail(service)) for service in SERVICES)
    pages.extend((f"/areas/{slug}/", area_page(slug, area)) for slug, area in LOCATIONS.items())
    for route, document in pages:
        write_page(route, document)
    shutil.copytree(ASSETS, OUT / "assets", ignore=shutil.ignore_patterns("*.md"))
    sitemap = [f"<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">"]
    for route, _ in pages:
        sitemap.append(f"  <url><loc>{escape(SITE_ORIGIN + route)}</loc><lastmod>{datetime.now().date().isoformat()}</lastmod></url>")
    sitemap.append("</urlset>")
    (OUT / "sitemap.xml").write_text("\n".join(sitemap) + "\n", encoding="utf-8")
    (OUT / "robots.txt").write_text(f"User-agent: *\nAllow: /\nSitemap: {SITE_ORIGIN}/sitemap.xml\n", encoding="utf-8")
    manifest = {"routes": [{"path": route, "title": title_for(route)} for route, _ in pages]}
    (OUT / "manus-routes.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (OUT / "404.html").write_text(shell("/404/", "Page not found", "The page could not be found.", f'<section class="page-hero page-hero-compact"><div class="wrap page-hero-inner"><h1>Page not found.</h1><p>Use the navigation to find a service or contact the team.</p><a class="button button-primary" href="/">Return to home</a></div></section>'), encoding="utf-8")
    print(f"Generated {len(pages)} static pages in {OUT}")


def title_for(route):
    if route == "/":
        return "Plumbing in NYC & Westchester"
    if route == "/services/":
        return "Plumbing Services"
    if route.startswith("/services/"):
        slug = route.strip("/").split("/")[-1]
        item = next(service for service in SERVICES if service["slug"] == slug)
        return item["title"]
    if route.startswith("/areas/") and route != "/areas/":
        slug = route.strip("/").split("/")[-1]
        return LOCATIONS[slug]["title"]
    return {"/projects/": "Project Examples", "/about/": "About Tap Plumbing Corp | NYC & Westchester", "/contact/": "Contact Tap Plumbing Corp | NYC & Westchester", "/estimate/": "Request a Plumbing Project Estimate", "/areas/": "Areas Served", "/privacy/": "Privacy & Prototype Notice"}.get(route, "Tap Plumbing Corp")


if __name__ == "__main__":
    build()
